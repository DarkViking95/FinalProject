#include <iostream>
#include <memory>

using namespace std;

struct Node {
    int key;
    shared_ptr<Node> left;
    shared_ptr<Node> right;

    Node(int k, shared_ptr<Node> l = nullptr, shared_ptr<Node> r = nullptr) {
        key = k;
        left = l;
        right = r;
    }
};

class persistentBST {
private:
    shared_ptr<Node> root;

    shared_ptr<Node> insert(shared_ptr<Node> node, int key) {
        if (!node) return make_shared<Node>(key);
        if (key < node->key) {
            return make_shared<Node>(node->key, insert(node->left, key), node->right);
        } else if (key > node->key) {
            return make_shared<Node>(node->key, node->left, insert(node->right, key));
        } else {
            return node;
        }
    }

    shared_ptr<Node> getMin(shared_ptr<Node> node) {
        while (node && node->left) node = node->left;
        return node;
    }

    shared_ptr<Node> deleteNode(shared_ptr<Node> node, int key) {
        if (!node) return nullptr;

        if (key < node->key) {
            return make_shared<Node>(node->key, deleteNode(node->left, key), node->right);
        } else if (key > node->key) {
            return make_shared<Node>(node->key, node->left, deleteNode(node->right, key));
        } else {
            // Node to delete is found
            // 1 child or 0 children
            if (!node->left) return node->right;
            if (!node->right) return node->left;

            // 2 children: find the inorder successor (smallest in right subtree)
            shared_ptr<Node> minNode = getMin(node->right);
            return make_shared<Node>(minNode->key, node->left, deleteNode(node->right, minNode->key));
        }
    }

    bool search(shared_ptr<Node> node, int key) {
        if (!node) return false;
        if (key == node->key) return true;
        if (key < node->key) return search(node->left, key);
        return search(node->right, key);
    }

    void inorder(shared_ptr<Node> node) {
        if (!node) return;
        inorder(node->left);
        cout << node->key << " ";
        inorder(node->right);
    }

public:
    persistentBST() { root = nullptr; }
    persistentBST(shared_ptr<Node> r) { root = r; }

    persistentBST insert(int key) {
        return persistentBST(insert(root, key));
    }

    persistentBST remove(int key) {
        return persistentBST(deleteNode(root, key));
    }

    bool search(int key) {
        return search(root, key);
    }

    void inorder() {
        inorder(root);
        cout << endl;
    }
};

int main() {
    persistentBST t1;
    // Build a tree
    auto t2 = t1.insert(10);
    auto t3 = t2.insert(5);
    auto t4 = t3.insert(15);
    auto t5 = t4.insert(7); // 5 has a right child (7)

    cout << "Original Tree (t5) inorder: ";
    t5.inorder(); // Should print: 5 7 10 15

    // Test Deletion
    auto t6 = t5.remove(5); 
    
    cout << "New Tree (t6) after removing 5: ";
    t6.inorder(); // Should print: 7 10 15

    cout << "Verify Original Tree (t5) is unmodified: ";
    t5.inorder(); // Should STILL print: 5 7 10 15

    return 0;
}