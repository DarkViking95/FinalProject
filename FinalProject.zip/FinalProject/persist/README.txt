Thursday, May 7 11:59 p.m.
Final Project
By: Ethan Bohling

Functions done:

int BinomialHeap::deleteMin();
void BinomialHeap::decreaseKey(int oldKey, int newKey);
void BinomialHeap::deleteKey(int key);
binomialNode* BinomialHeap::findNode(binomialNode* node, int key);

How to compile/run program
To compile: type make in terminal
To run: type ./p_bst_1 for p_bst_1.cpp
To run: type ./p_bst_fat for p_bst_fat.cpp
To run: type ./