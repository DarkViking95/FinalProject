#include <iostream>
#include <vector>
#include <memory>

using namespace std;

struct FatNode;

struct VersionEntry {
    int version;
    shared_ptr<FatNode> left;
    shared_ptr<FatNode> right;
};

struct FatNode {
    int key;
    vector<VersionEntry> history;

    FatNode(int k, int ver, shared_ptr<FatNode> l = nullptr, shared_ptr<FatNode> r = nullptr) {
        key = k;
        history.push_back({ver, l, r});
    }

    VersionEntry getVersion(int ver) {
        VersionEntry latest = {-1, nullptr, nullptr};
        for (const auto& entry : history) {
            if (entry.version <= ver) {
                latest = entry;
            } else {
                break;
            }
        }
        return latest;
    }
};

class FatPersistentBST {
private:
    int current_version = 0;
    shared_ptr<FatNode> root;

    shared_ptr<FatNode> insertFat(shared_ptr<FatNode> node, int key, int ver) {
        if (!node) return make_shared<FatNode>(key, ver);

        VersionEntry vData = node->getVersion(ver - 1);
        shared_ptr<FatNode> newLeft = vData.left;
        shared_ptr<FatNode> newRight = vData.right;

        if (key < node->key) {
            newLeft = insertFat(vData.left, key, ver);
        } else if (key > node->key) {
            newRight = insertFat(vData.right, key, ver);
        } else {
            return node; // No duplicates
        }

        // Add to history instead of duplicating the node
        node->history.push_back({ver, newLeft, newRight});
        return node;
    }

    void inorderFat(shared_ptr<FatNode> node, int ver) {
        if (!node) return;
        VersionEntry vData = node->getVersion(ver);
        inorderFat(vData.left, ver);
        cout << node->key << " ";
        inorderFat(vData.right, ver);
    }

public:
    FatPersistentBST() { root = nullptr; }

    int insert(int key) {
        current_version++;
        if (!root) {
            root = make_shared<FatNode>(key, current_version);
        } else {
            insertFat(root, key, current_version);
        }
        return current_version;
    }

    void inorder(int ver) {
        cout << "Version " << ver << " inorder: ";
        inorderFat(root, ver);
        cout << endl;
    }
};

int main() {
    FatPersistentBST tree;
    
    cout << "Inserting nodes..." << endl;
    int v1 = tree.insert(10); // Version 1: just 10
    int v2 = tree.insert(5);  // Version 2: 5, 10
    int v3 = tree.insert(15); // Version 3: 5, 10, 15
    int v4 = tree.insert(7);  // Version 4: 5, 7, 10, 15

    // Test Time Travel
    cout << "Testing Version 2 (Should be 5 10): ";
    tree.inorder(v2); 

    cout << "Testing Version 4 (Should be 5 7 10 15): ";
    tree.inorder(v4); 

    return 0;
}