#include <iostream>
#include <memory>
#include <functional>

using namespace std;

template <typename T>
struct LazyNode;

template <typename T>
using Stream = shared_ptr<LazyNode<T>>;

template <typename T>
struct LazyNode {
    T value;
    function<Stream<T>()> thunk;
    Stream<T> evaluated_next;
    bool is_evaluated;

    LazyNode(T val, function<Stream<T>()> t = nullptr) 
        : value(val), thunk(t), evaluated_next(nullptr), is_evaluated(t == nullptr) {}

    Stream<T> next() {
        if (!is_evaluated) {
            evaluated_next = thunk();
            is_evaluated = true;
        }
        return evaluated_next;
    }
};

// Incremental reversal - FIXED!
template <typename T>
Stream<T> reverseConcat(Stream<T> front, Stream<T> rear, Stream<T> acc) {
    // FIXED BASE CASE: If front is empty, rear still has exactly 1 element left.
    // We must attach this final rear element to the front of our accumulator.
    if (!front) {
        return make_shared<LazyNode<T>>(rear->value, [=]() { return acc; });
    }
    
    return make_shared<LazyNode<T>>(front->value, [=]() {
        return reverseConcat(front->next(), rear->next(), make_shared<LazyNode<T>>(rear->value, [=]() { return acc; }));
    });
}

template <typename T>
class lazyPersistentQueue {
private:
    Stream<T> front;
    Stream<T> rear;
    int frontSize;
    int rearSize;

    lazyPersistentQueue balance() {
        if (rearSize <= frontSize) {
            return *this;
        }
        // Incrementally build the new front by deferring the operation
        Stream<T> newFront = reverseConcat(front, rear, Stream<T>(nullptr));
        return lazyPersistentQueue(newFront, nullptr, frontSize + rearSize, 0);
    }

public:
    lazyPersistentQueue() : front(nullptr), rear(nullptr), frontSize(0), rearSize(0) {}

    lazyPersistentQueue(Stream<T> f, Stream<T> r, int fsize, int rsize) 
        : front(f), rear(r), frontSize(fsize), rearSize(rsize) {}

    bool isEmpty() { return frontSize == 0; }

    lazyPersistentQueue enqueue(T x) {
        auto newRear = make_shared<LazyNode<T>>(x, [r=rear]() { return r; });
        return lazyPersistentQueue(front, newRear, frontSize, rearSize + 1).balance();
    }

    lazyPersistentQueue dequeue() {
        if (isEmpty()) throw runtime_error("Queue is empty");
        return lazyPersistentQueue(front->next(), rear, frontSize - 1, rearSize).balance();
    }

    T peek() {
        if (isEmpty()) throw runtime_error("Queue is empty");
        return front->value;
    }
};

int main() {
    lazyPersistentQueue<int> q1;
    
    // Enqueue items
    auto q2 = q1.enqueue(10);
    auto q3 = q2.enqueue(20);
    auto q4 = q3.enqueue(30);
    
    // Dequeue an item (this forces the lazy evaluation/balancing behind the scenes)
    auto q5 = q4.dequeue(); 

    // Test states
    cout << "Front of q4 (before dequeue): " << q4.peek() << endl; // Should be 10
    cout << "Front of q5 (after dequeue): " << q5.peek() << endl;  // Should be 20
    
    // Prove persistence (q4 should not have been altered by q5's dequeue)
    cout << "Front of q4 is STILL: " << q4.peek() << endl; // Should be 10

    return 0;
}